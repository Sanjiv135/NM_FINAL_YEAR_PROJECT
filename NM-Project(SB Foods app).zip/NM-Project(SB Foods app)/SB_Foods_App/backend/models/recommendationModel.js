
const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    dishes: [{ name: String, popularity: Number }],
});

module.exports = mongoose.model('Recommendation', recommendationSchema);
