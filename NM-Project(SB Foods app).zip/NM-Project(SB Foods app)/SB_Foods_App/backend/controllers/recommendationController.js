
const Recommendation = require('../models/recommendationModel');

exports.getRecommendations = async (req, res) => {
    try {
        const userId = req.params.userId;
        const recommendations = await Recommendation.find({ userId });
        res.json(recommendations);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching recommendations' });
    }
};
