
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.json());

io.on('connection', (socket) => {
    console.log('User connected');

    socket.on('joinOrderRoom', (orderId) => {
        socket.join(orderId);
        console.log(`User joined room: ${orderId}`);
    });

    socket.on('orderUpdate', ({ orderId, status }) => {
        io.to(orderId).emit('orderStatusUpdate', status);
    });
});

app.listen(5000, () => console.log('Server running on port 5000'));
