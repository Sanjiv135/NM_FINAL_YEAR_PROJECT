
import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

const OrderTracking = ({ orderId }) => {
    const [status, setStatus] = useState('Processing');

    useEffect(() => {
        socket.emit('joinOrderRoom', orderId);

        socket.on('orderStatusUpdate', (updatedStatus) => {
            setStatus(updatedStatus);
        });

        return () => {
            socket.disconnect();
        };
    }, [orderId]);

    return (
        <div>
            <h3>Order Status: {status}</h3>
        </div>
    );
};

export default OrderTracking;
