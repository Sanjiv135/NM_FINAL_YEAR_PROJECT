
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Recommendations = ({ userId }) => {
    const [recommendedDishes, setRecommendedDishes] = useState([]);

    useEffect(() => {
        const fetchRecommendations = async () => {
            const { data } = await axios.get(`/api/recommendations/${userId}`);
            setRecommendedDishes(data);
        };
        fetchRecommendations();
    }, [userId]);

    return (
        <div>
            <h2>Recommended for You</h2>
            <ul>
                {recommendedDishes.map((dish) => (
                    <li key={dish.id}>{dish.name}</li>
                ))}
            </ul>
        </div>
    );
};

export default Recommendations;
