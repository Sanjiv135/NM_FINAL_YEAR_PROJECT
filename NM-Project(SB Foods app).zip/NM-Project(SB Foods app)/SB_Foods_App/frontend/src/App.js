
import React from 'react';
import Recommendations from './components/Recommendations';
import OrderTracking from './components/OrderTracking';

const App = () => {
    return (
        <div>
            <h1>SB Food Ordering App</h1>
            <Recommendations userId="12345" />
            <OrderTracking orderId="67890" />
        </div>
    );
};

export default App;
